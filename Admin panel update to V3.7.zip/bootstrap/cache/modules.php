<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\AI\\app\\Providers\\AIServiceProvider',
    1 => 'Modules\\AddonModule\\Providers\\AddonModuleServiceProvider',
    2 => 'Modules\\BidModule\\Providers\\BidModuleServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\AI\\app\\Providers\\AIServiceProvider',
    1 => 'Modules\\AddonModule\\Providers\\AddonModuleServiceProvider',
    2 => 'Modules\\BidModule\\Providers\\BidModuleServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);